Instructions to install and activate the APIs required for ECATT based automation of ODATA Services.

Pre-requisite:  The target system where these APIs can be installed should be on SAP Netweaver Gateway 2.0 SP6 or higher:


1. Please install the latest ZSAPLINK installer following the instruction from the following link:
http://wiki.sdn.sap.com/wiki/display/ABAP/SAPlink+User+Documentation

For convinience sake, please find attached the SAPlink_Daily.nugg.zip file (dated 15 May) which creates the report program "ZSAPLINK"

You have to activate the report program "ZSAPLINK" explicitly after the import is successfull (from se38 or se80)


2. Additionally install the following attached plugins by executing ZSAPLINK report program in se38 (using the "Import Nuggets" (for .nugg) or Import Slinkee (for .slnk) tab  ):

2.a. NUGG_SAPLINK_DDIC-0.1.0.nugg - to be able to import DDIC objects like structures and table types

2.b. CLAS_ZSAPLINK_MESSAGE_CLASS-0.1.0.slnk - to be able to import Message class

2.c. NUGG_FUNCTIONGROUP_PLUGIN-0.1.2.nugg

Once imported please explicitly activate at least the following classes from se24 / se80 (you may chose to activate all the objects ZSAPLINK* in your worklist under Local Objects in se80):

ZSAPLINK_MESSAGE_CLASS
ZSAPLINK_TABLES
ZSAPLINK_TABLE_TYPES
ZSAPLINK_FUNCTIONGROUP


3. Now execute the report "ZSAPLINK" from se38 and import the following Slinkee files individually and activate the corresponding object, in the following sequence:

3.a. TABL_ZPROPERTY_NAMEVALUE_ST.slnk 
Once imported, go to transaction se11, select radio button against "Data type" and enter the value "ZPROPERTY_NAMEVALUE_ST".
Display the structure and activate the same

3.b. TTYP_ZPROPERTY_NAMEVALUE_TT.slnk
Once imported, go to transaction se11, select radio button against "Data type" and enter the value "ZPROPERTY_NAMEVALUE_TT".
Display the table type and activate the same

3.c. MSAG_ZODATA_TEST_AUTO_MSG.slnk
Once imported, go to transaction se80 or se91 and verify that the Message Class "ZODATA_TEST_AUTO_MSG" exists as "Active"

3.d. FUGR_ZODATA_TEST_AUTOMATION_FGR.slnk

Once imported, go to transaction se80, select the "Function Group" from the drop-down and enter "ZODATA_TEST_AUTOMATION_FGR" to display the details.

In the left tree view, you should see following function modules in "Inactive" state under the Function Group:

ZODATA_TEST_CREATE_ENTRY
ZODATA_TEST_UPDATE_ENTRY
ZODATA_TEST_DELETE_ENTRY
ZODATA_TEST_ENTRY
ZODATA_TEST_FEED
ZODATA_TEST_INVOKE_DELE
ZODATA_TEST_INVOKE_GET
ZODATA_TEST_INVOKE_POST
ZODATA_TEST_INVOKE_PUT
ZODATA_TEST_METADATA
ZODATA_TEST_SERVDOC

Right-click on the Function Group and activate all the function modules in one shot.




